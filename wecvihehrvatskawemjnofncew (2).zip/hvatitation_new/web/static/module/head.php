<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo $_server->site_name; ?></title>
<link rel="icon" type="image/x-icon" href="/assets/images/fav.png">
<link rel="stylesheet" href="/assets/css/hvatitation.css">
<script src="/assets/scripts/hvatitation.js"></script>
<style>@import url('https://fonts.googleapis.com/css2?family=Source+Sans+3:ital,wght@0,200..900;1,200..900&display=swap');</style>