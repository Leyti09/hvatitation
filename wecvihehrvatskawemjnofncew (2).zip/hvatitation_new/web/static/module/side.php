<aside class="sidebar">
    <h3>Categories</h3>
    <ul>
        <li><a href="/category/Digital%20Art">Digital Art</a></li>
        <li><a href="/category/Traditional%20Art">Traditional Art</a></li>
        <li><a href="/category/Photography">Photography</a></li>
        <li><a href="/category/Artisan%20Crafts">Artisan Crafts</a></li>
        <li><a href="/category/Literature">Literature</a></li>
        <li><a href="/category/Comics%20and%20Cartoons">Comics & Cartoons</a></li>
        <li><a href="/category/Customizations">Customizations</a></li>
    </ul>
</aside>