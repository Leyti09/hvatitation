<?php
    require_once($_SERVER['DOCUMENT_ROOT'] . '/static/classes/initialize.php');
?>
<!DOCTYPE html>
<html lang="en"> 
<head>
    <?php require_once($_SERVER['DOCUMENT_ROOT'] . '/static/module/head.php'); ?>
</head>
<body>
    <?php require_once($_SERVER['DOCUMENT_ROOT'] . '/static/module/header.php'); ?>
    <div class="container">
        <?php require_once($_SERVER['DOCUMENT_ROOT'] . '/static/module/side.php'); ?>
        <div>
        <h1 style="margin-left:12px;">Rules and Guidelines</h1>
            <ul>
                <li>
                    Don't post sexually explicit material
                </li>
                <li>
                    Don't post heavily graphic content
                </li>
                <li>
                    Only post content you have originally created
                </li>
                <li>
                    **This page will be updated with higher quality information soon**
                </li>
            </ul>
        </div>
    </div>
    <?php require_once($_SERVER['DOCUMENT_ROOT'] . '/static/module/footer.php'); ?>
</body>
</html>
